$('.hotlist .hotlist_head_info .hotlist_head_top1 .gstop').height($('.hotlist .hotlist_head_info .hotlist_head_top1 .gstop').width());
$('.hotlist .hotlist_head_info .hotlist_head_top2 .gstop').height($('.hotlist .hotlist_head_info .hotlist_head_top2 .gstop').width());
$('.hotlist .hotlist_head_info .hotlist_head_top3 .gstop').height($('.hotlist .hotlist_head_info .hotlist_head_top3 .gstop').width());
$('.hotlist .hotlist_content ul li img').height($('.hotlist .hotlist_content ul li img').width());