$('.myuserinfo img').height($('.myuserinfo img').width());
$("#yaya").click(function(){
    $("#overlay").addClass("overlay");
    $("#overlaytwo").show();
});
$("#yaya1").click(function(){
    $("#overlay").addClass("overlay");
    $("#overlaythree").show();
});
$("#overlaytwo").click(function(){
    $("#overlay").removeClass("overlay");
    $("#overlaytwo").hide();
});
$("#overlaythree").click(function(){
    $("#overlay").removeClass("overlay");
    $("#overlaythree").hide();
});
