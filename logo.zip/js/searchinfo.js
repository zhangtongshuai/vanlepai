$('.searchinfo .search_info_list li img').height($('.searchinfo .search_info_list li img').width()*1.15);
$('.searchinfo .search_info_list li').height($('.searchinfo .search_info_list li img').width()*1.35);
$('.classify_info ol').find('li').click(function(){
    $('.classify_info_list .rightan').show();
    var index = $(this).index();
    $(this).addClass('aui-active').siblings().removeClass('aui-active');
    $('.classify_info_list').find('.classify_info_list_centent').removeClass('now_show');
    $('.classify_info_list').find('.classify_info_list_centent').eq(index).addClass('now_show');
});
$('.classify_info .classify_info_list .classify_info_list_centent li').on('click',function () {
    $('.classify_info_list .rightan').hide();
    $('.classify_info .classify_info_list .classify_info_list_centent li').removeClass('active');
    $(this).addClass('active');
    $(this).parents('.classify_info_list_centent').removeClass('now_show');
});
$('.classify_info_list .rightan').find('img').on('click',function () {
    $(this).parents('.rightan').hide();
    $('.classify_info_list .classify_info_list_centent').removeClass('now_show');
});