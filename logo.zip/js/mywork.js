$('.mywork .mystory li .backbtns').height($('.mywork .mystory li .backbtns').width());
$('.mywork .mystory li .backbtns').height($('.mywork .mystory li .backbtns').width());
$(document).on('click','.img1',function () {
    $(this).addClass('img2');
    $(this).removeClass('img1');
    $(this).attr('src','img/bfbtn2.png');
    $(this).parent('div').addClass('zhuand');
});
$(document).on('click','.img2',function () {
    $(this).addClass('img1');
    $(this).removeClass('img2');
    $(this).attr('src','img/bfbtn1.png');
    $(this).parent('div').removeClass('zhuand');
});
$('.mywork .aui-tab .aui-tab-item').click(function(){
    var index = $(this).index();
    $(this).addClass('aui-active').siblings().removeClass('aui-active');
    $('.mywork .mywork_list').find('.mywork_list_info').removeClass('now_show');
    $('.mywork .mywork_list').find('.mywork_list_info').eq(index).addClass('now_show');
});