$('.storyparty .hot_story li .backbtns').height($('.storyparty .hot_story li .backbtns').width());
$('.storyparty .new_story li .backbtns').height($('.storyparty .new_story li .backbtns').width());
$(document).on('click','.img1',function () {
    $(this).addClass('img2');
    $(this).removeClass('img1');
    $(this).attr('src','img/bfbtn2.png');
    $(this).parent('div').addClass('zhuand');
});
$(document).on('click','.img2',function () {
    $(this).addClass('img1');
    $(this).removeClass('img2');
    $(this).attr('src','img/bfbtn1.png');
    $(this).parent('div').removeClass('zhuand');
});
$('.storyparty .aui-tab .aui-tab-item').click(function(){
    var index = $(this).index();
    $(this).addClass('aui-active').siblings().removeClass('aui-active');
});