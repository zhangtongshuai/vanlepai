var slide3 = new auiSlide({
    container:document.getElementById("aui-slide3"),
    // "width":300,
    "height":240,
    "speed":500,
    "autoPlay": 5000, //自动播放
    "loop":true,
    "pageShow":true,
    "pageStyle":'line',
    'dotPosition':'center'
});
var swiper = new Swiper('.swiper-container', {
    slidesPerView: 2,
    spaceBetween: 30,
    freeMode: true,
    loop : true,
    autoplay:3000
    // pagination: '.swiper-pagination',
});
//超人气故事
$('.index .swiper-slide img').height($('.index .swiper-slide img').width()*1.15);
$('.index .swiper-slide').height($('.index .swiper-slide img').width()*1.35);
//最新故事
$('.index .new_story li img').height($('.index .new_story li img').width()*1.15);
$('.index .new_story li').height($('.index .new_story li img').width()*1.35);
$('#search .aui-searchbar-confirm').on('click',function () {
    window.location.href = 'searchinfo.html';
});