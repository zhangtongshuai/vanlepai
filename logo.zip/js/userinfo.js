$('.mystory li .backbtns').height($('.mystory li .backbtns').width());
$('.mystory li .backbtns').height($('.mystory li .backbtns').width());
$(document).on('click','.img1',function () {
    $(this).addClass('img2');
    $(this).removeClass('img1');
    $(this).attr('src','img/bfbtn2.png');
    $(this).parent('div').addClass('zhuand');
});
$(document).on('click','.img2',function () {
    $(this).addClass('img1');
    $(this).removeClass('img2');
    $(this).attr('src','img/bfbtn1.png');
    $(this).parent('div').removeClass('zhuand');
});
$('.userinfo .aui-tab .aui-tab-item').click(function(){
    var index = $(this).index();
    $(this).addClass('aui-active').siblings().removeClass('aui-active');
    $('.userinfo .user_content').find('.user_content_list').removeClass('now_show');
    $('.userinfo .user_content').find('.user_content_list').eq(index).addClass('now_show');
});

// 滚动页面时  aui-tab 在顶部
var uhead_height = $('.userinfo .userinfo_head').height();
var aui_tab_height = $('.userinfo .aui-tab').height();
var scrollHeight = uhead_height + aui_tab_height;
$(window).scroll(function() {
    if($(window).scrollTop()>=scrollHeight){
        $(".userinfo .aui-tab").css({'position':'fixed'});
    }else{
        $(".userinfo .aui-tab").css({'position':'relative'});
    }
});
$(window).scrollTop(0);